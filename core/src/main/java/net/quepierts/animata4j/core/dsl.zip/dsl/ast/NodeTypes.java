package net.quepierts.animata4j.core.dsl.ast;

import lombok.experimental.UtilityClass;
import net.quepierts.animata4j.core.dsl.TypeIdentifier;

@UtilityClass
public class NodeTypes {
    public static final TypeIdentifier<ExpressionNode.Number> NUMBER = TypeIdentifier.of(Keys.NUMBER);
    public static final TypeIdentifier<ExpressionNode.Word> WORD = TypeIdentifier.of(Keys.WORD);

    public static final TypeIdentifier<ExpressionNode.BinaryOperation> BINARY_OPERATION = TypeIdentifier.of(Keys.BINARY_OPERATION);
    public static final TypeIdentifier<ExpressionNode.UnaryOperation> UNARY_OPERATION = TypeIdentifier.of(Keys.UNARY_OPERATION);

    @UtilityClass
    public static class Keys {
        public static final String NUMBER = "NUMBER";
        public static final String WORD = "WORD";

        public static final String BINARY_OPERATION = "BINARY_OPERATION";
        public static final String UNARY_OPERATION = "UNARY_OPERATION";
    }
}
