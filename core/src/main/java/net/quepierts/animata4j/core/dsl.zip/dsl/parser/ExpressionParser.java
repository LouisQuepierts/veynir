package net.quepierts.animata4j.core.dsl.parser;

import net.quepierts.animata4j.core.dsl.SourceSpan;
import net.quepierts.animata4j.core.dsl.ast.ExpressionNode;
import net.quepierts.animata4j.core.dsl.lexer.ExpressionLexer;
import net.quepierts.animata4j.core.dsl.token.ExpressionToken;
import net.quepierts.animata4j.core.dsl.token.Token;
import net.quepierts.animata4j.core.dsl.token.TokenTypes;
import org.jetbrains.annotations.NotNull;

public class ExpressionParser extends Parser {

    public ExpressionParser(final @NotNull ExpressionLexer lexer) {
        super(lexer);
    }

    public @NotNull ExpressionNode parse() {
        return this.parseExpression();
    }

    /*
    <expression> ::= <term> [ (ADD | SUB) <term> ]*
    * */
    private ExpressionNode parseExpression() {
//        System.out.println("Expression");
        ExpressionNode node = this.parseTerm();
        Token current = this.getCurrent();
        while (current.is(TokenTypes.ADD)
                || current.is(TokenTypes.SUB)) {
            ExpressionToken.Symbol symbol = (ExpressionToken.Symbol) current;
            this.advance();

            ExpressionNode right = this.parseTerm();
            node = new ExpressionNode.BinaryOperation(
                    SourceSpan.of(node.getSpan().getBegin(), right.getSpan().getEnd()),
                    node, right,
                    symbol.getType()
            );
            current = this.getCurrent();
        }

        return node;
    }

    /*
    <term> ::= <unary> [ (MUL | DIV | MOD) <unary> ]*
    */
    private ExpressionNode parseTerm() {
//        System.out.println("Term");
        ExpressionNode node = this.parseUnary();
        Token current = this.getCurrent();

        while (current.is(TokenTypes.MUL)
                || current.is(TokenTypes.DIV)
                || current.is(TokenTypes.MOD)) {
            ExpressionToken.Symbol symbol = (ExpressionToken.Symbol) current;
            this.advance();

            ExpressionNode right = this.parseUnary();
            node = new ExpressionNode.BinaryOperation(
                    SourceSpan.of(node.getSpan().getBegin(), right.getSpan().getEnd()),
                    node, right,
                    symbol.getType()
            );
            current = this.getCurrent();
        }
        return node;
    }

    /*
    <unary> ::= [ (ADD | SUB) ] <primary> | <power>
     */
    private ExpressionNode parseUnary() {
//        System.out.println("Unary");
        Token current = this.getCurrent();
        if (current.is(TokenTypes.ADD)
                || current.is(TokenTypes.SUB)) {
            ExpressionToken.Symbol symbol = (ExpressionToken.Symbol) current;
            this.advance();

            ExpressionNode node = this.parsePrimary();
            return new ExpressionNode.UnaryOperation(
                    SourceSpan.of(symbol.getSpan().getBegin(), node.getSpan().getEnd()),
                    node,
                    symbol.getType()
            );
        } else {
            return this.parsePower();
        }
    }

    /*
    <power> ::= <primary> [ POW <primary> ]?
    */
    private ExpressionNode parsePower() {
//        System.out.println("Power");
        ExpressionNode node = this.parsePrimary();
        Token current = this.getCurrent();

        if (current.is(TokenTypes.POW)) {
            ExpressionToken.Symbol symbol = (ExpressionToken.Symbol) current;
            this.advance();
            ExpressionNode right = this.parsePrimary();
            node = new ExpressionNode.BinaryOperation(
                    SourceSpan.of(node.getSpan().getBegin(), right.getSpan().getEnd()),
                    node, right,
                    symbol.getType()
            );
        }
        return node;
    }

    /*
    <primary> ::= <number>
                  | <word>
                  | LPAREN <expression> RPAREN
    */
    private @NotNull ExpressionNode parsePrimary() {
//        System.out.println("Primary");
        Token current = this.getCurrent();

        if (current.is(TokenTypes.NUMBER)) {
            ExpressionToken.Number number = (ExpressionToken.Number) current;
            this.advance();
            return new ExpressionNode.Number(
                    number.getSpan(),
                    number.getValue()
            );
        } else if (current.is(TokenTypes.WORD)) {
            ExpressionToken.Word word = (ExpressionToken.Word) current;
            this.advance();
            return new ExpressionNode.Word(
                    word.getSpan(),
                    word.getValue()
            );
        } else if (current.is(TokenTypes.LPAREN)) {
            this.advance();
            ExpressionNode node = this.parseExpression();
            this.expect(TokenTypes.RPAREN);
            return node;
        }

        throw new RuntimeException(); // unreachable
    }
}
