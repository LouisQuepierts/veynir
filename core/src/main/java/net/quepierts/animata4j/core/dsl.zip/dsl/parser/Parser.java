package net.quepierts.animata4j.core.dsl.parser;

import lombok.AccessLevel;
import lombok.Getter;
import net.quepierts.animata4j.core.dsl.SourcePos;
import net.quepierts.animata4j.core.dsl.SourceSpan;
import net.quepierts.animata4j.core.dsl.TypeIdentifier;
import net.quepierts.animata4j.core.dsl.ast.Node;
import net.quepierts.animata4j.core.dsl.lexer.ExpressionLexer;
import net.quepierts.animata4j.core.dsl.token.Token;
import org.jetbrains.annotations.NotNull;

public abstract class Parser {
    private final ExpressionLexer lexer;

    @Getter(AccessLevel.PROTECTED)
    private Token current;

    protected Parser(final @NotNull ExpressionLexer lexer) {
        this.lexer = lexer;
        this.advance();
    }

    public abstract Node parse();

    protected void advance() {
//        System.out.println("Advance");
        this.current = this.lexer.next();
    }

    protected boolean match(final @NotNull TypeIdentifier<? extends Token> type) {
        if (this.current != null && this.current.is(type)) {
            this.advance();
            return true;
        }
        return false;
    }

    protected void expect(final @NotNull TypeIdentifier<? extends Token> type) {
        if (!this.match(type)) {
            this.errorExpected(type.toString(), this.current.toString());
        }
    }

    protected void error(String message) {
        final Token current = this.getCurrent();
        final SourceSpan span = current.getSpan();
        final SourcePos pos = span.getBegin();

        StringBuilder builder = new StringBuilder();
        builder.append("Parse error: ").append(message).append("\n")
                .append("at line ").append(pos.getLine() + 1)
                .append(", col ").append(pos.getCol() + 1).append("\n");

        throw new RuntimeException(builder.toString());
    }

    // 用于报错时“预期但未匹配”的情况
    protected void errorExpected(String expected, String actual) {
        error("Expected " + expected + " but found '" + actual + "'");
    }
}
