package net.quepierts.animata4j.core.dsl.token;

import lombok.experimental.UtilityClass;
import net.quepierts.animata4j.core.dsl.TypeIdentifier;

@UtilityClass
public class TokenTypes {

    public static final TypeIdentifier<EOFToken> EOF = TypeIdentifier.of(Keys.EOF);

    public static final TypeIdentifier<PathToken.Simple> SIMPLE = TypeIdentifier.of(Keys.SIMPLE);
    public static final TypeIdentifier<PathToken.Subscript> SUBSCRIPT = TypeIdentifier.of(Keys.SUBSCRIPT);

    public static final TypeIdentifier<ExpressionToken.Number> NUMBER = TypeIdentifier.of(Keys.NUMBER);
    public static final TypeIdentifier<ExpressionToken.Word> WORD = TypeIdentifier.of(Keys.WORD);

    public static final TypeIdentifier<ExpressionToken.Symbol> ADD = TypeIdentifier.of(Keys.ADD);
    public static final TypeIdentifier<ExpressionToken.Symbol> SUB = TypeIdentifier.of(Keys.SUB);
    public static final TypeIdentifier<ExpressionToken.Symbol> MUL = TypeIdentifier.of(Keys.MUL);
    public static final TypeIdentifier<ExpressionToken.Symbol> DIV = TypeIdentifier.of(Keys.DIV);
    public static final TypeIdentifier<ExpressionToken.Symbol> MOD = TypeIdentifier.of(Keys.MOD);
    public static final TypeIdentifier<ExpressionToken.Symbol> POW = TypeIdentifier.of(Keys.POW);
    public static final TypeIdentifier<ExpressionToken.Symbol> LPAREN = TypeIdentifier.of(Keys.LPAREN);
    public static final TypeIdentifier<ExpressionToken.Symbol> RPAREN = TypeIdentifier.of(Keys.RPAREN);

    @UtilityClass
    public static class Keys {
        public static final String EOF = "EOF";
        
        public static final String SIMPLE = "SIMPLE";
        public static final String SUBSCRIPT = "SUBSCRIPT";
        
        public static final String NUMBER = "NUMBER";
        public static final String WORD = "WORD";
        
        public static final String ADD = "ADD";
        public static final String SUB = "SUB";
        public static final String MUL = "MUL";
        public static final String DIV = "DIV";
        public static final String MOD = "MOD";
        public static final String POW = "POW";
        public static final String LPAREN = "LPAREN";
        public static final String RPAREN = "RPAREN";
    }
}
